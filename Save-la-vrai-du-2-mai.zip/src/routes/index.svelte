<script>
	import bornes from'$lib/listing.js'

  
  function NbrPlaceDisp(tab) {
    return tab.reduce((partialSum, a) => partialSum + a, 0);
  }

  function NbrPlace(tab) {
    return tab.reduce((partialSum) => partialSum + 1, 0);
  }

</script>

<section>

<head>
  <meta charset="UTF-8" />
  <link
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
  />
</head>

<body>
  <ul>
    <li class="menu-deroulant">
      <a href="#">Choix de la borne</a>
      <ul class="sous-menu">
				{#each bornes as borne }
					<a href = {borne.id}>
            <li>
              <table>
                <td class="name">{borne.name}</td>
                <td>
                  {NbrPlaceDisp(borne.emplacements)}/{NbrPlace(borne.emplacements)}
                </td>
              </table>
					  </li>
          </a>
				{/each}
      </ul>
    </li>
  </ul>
</body>

</section>

<style>
:root {
  --hauteur-menu: 60px;
}

* {
  margin: 0px;
  padding: 0px;
  font-family: Montserrat, sans-serif;
}

body {
  font-size: 18px;
  position: sticky;
}

body > ul {
  margin-top: 200px;
  width: 100%;
  display: flex;
  box-shadow: 0px 1px 2px 1px rgba(0, 0, 0, 0.3);
  height: var(--hauteur-menu);
	list-style: none;
}

body > ul > li {
  background-color: white;
  position: relative;
  height: 100%;
  flex: 1;
}

body > ul > li:hover > a {
  color: #2169ec;
}

body > ul > li > a {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

li a {
  text-decoration: none;
  color: black;
}

.menu-deroulant > a:after {
  content: '❯';
  font-size: 15px;
  margin-left: 7px;
  display: inline-block;
}

.menu-deroulant:hover > a:after {
  animation: rotationFleche 0.2s linear forwards;
}

@keyframes rotationFleche {
  0% {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(45deg);
  }
  100% {
    transform: rotate(90deg);
  }
}

.sous-menu {
  margin-top: var(--hauteur-menu);
  width: 100%;
  text-align: left;
  overflow: hidden;
  max-height: 0;
  border-radius: 2px;
  background-color: white;
}

.menu-deroulant:hover > .sous-menu {
  animation: apparitionSousMenu 1s forwards;
}

@keyframes apparitionSousMenu {
  0% {
    box-shadow: 0px 3px 3px 1px rgba(0, 0, 0, 0);
    border-top: 3px solid #2169ec;
  }
  30% {
    box-shadow: 0px 3px 3px 1px rgba(0, 0, 0, 0.3);
  }
  100% {
    max-height: 50em;
    border-top: 3px solid #2169ec;
    box-shadow: 0px 3px 3px 1px rgba(0, 0, 0, 0.3);
  }
}

.sous-menu > li:hover {
  background-color: rgba(33, 105, 236, 0.3);
}

.sous-menu > li > a {
  align-items: center;
  display: flex;
  height: 50px;
  padding-left: 20px;
  width: 100%;
}

.sous-menu > li:hover > a {
  color: white;
}


.name {
  width: 100%;
}
</style>