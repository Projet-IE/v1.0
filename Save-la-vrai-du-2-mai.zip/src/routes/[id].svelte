<script>
  import { page } from '$app/stores';
  import bornes from '$lib/listing.js';
  import user from '$lib/listing.js';

  let borne = bornes.find(borne => borne.id === parseInt($page.params.id))

  //Button qui fait une action quand on clique dessus
  function selectionBorne() {
		alert('Vous avez selectionné la borne ')
	}
</script>

{#if borne}
  <h1 class="titre">{borne.name}</h1>

  <div class="adresse">{borne.adresse}</div>

  <div class="choix_emplacement">
    Veuillez choisir un emplacement
  </div>

  <div class="parent-element">
  
  {#each borne.emplacements as emplacement, i}
    
    {#if emplacement ==1}
      <button on:click|once={selectionBorne} class="emplacement-disponible emplacement-box">{i+1}</button>
    {/if}
    {#if emplacement ==0}
      <div class="emplacement-indisponible emplacement-box">{i+1}</div>
    {/if}
    
  {/each}
  </div>

{/if}

<style>


.emplacement-disponible{
  
  background-color: #70AD47;
  border: 2px solid #70AD47 !important;
  

}
.emplacement-indisponible{
  
  background-color: #DDDDDD;
  border: 2px solid #DDDDDD !important;
  
}

.emplacement-box{
  border-radius: 15px;
  border: 2px solid #73AD21;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 1vw;
  width:10vw;
  height:10vw;
}

.parent-element{
  display: flex;
}

.titre{
  margin-top : 40 px;
}

.adresse{
  text-align : center;
  margin-top : 30px
}


  .choix_emplacement{
  text-align : center;
  margin-top : 50px
  }

.emplacement{
  background : black;
  border-width:1px;
  border-style:solid;
  border-color:black;
  margin-top : 20px
  }



</style>