# sveltejs-kit-template-default-ixhdbh

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/sveltejs-kit-template-default-ixhdbh)